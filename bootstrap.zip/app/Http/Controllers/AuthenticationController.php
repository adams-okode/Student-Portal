<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\User;

class AuthenticationController extends Controller
{
    //
    public function login(Request $request)
    {
    	# code...
        $email=$request->input('email');
        $password=$request->input('password');

        if (Auth::attempt(['email'=>$email,'password'=>$password])) {
            return redirect('home');
        } else {
            return redirect()->back()->withErrors([
                'error'=>'username or password invalid',
            ]);
        }
        
    }


    public function register(Request $request)
    {
        # code...
        $user= new User;
        $user->fname='Adams';
        $user->lname='Okode';
        $user->role='admin';
        $user->dob=date('Y-m-d');
        $user->admission_no=0;
        $user->class=1;
        $user->email='adamsokode@gmail.com';
        $user->password=\Hash::make('123456');
        
        $user->save();


    }
}
