<?php
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//login page
Route::get('/', function () {
    return view('welcome');
});

//view management
Route::get('/home','ViewsController@home');
Route::get('/classes','ViewsController@classes');
Route::get('/classdetails','ViewsController@classdetails');
Route::get('/exams','ViewsController@exams');
Route::get('/questions','ViewsController@questions');
Route::get('/answers','ViewsController@answers');
Route::get('/account','ViewsController@account');
Route::get('/students','ViewsController@students');
Route::get('/teachers','ViewsController@teachers');
Route::get('/progress','ViewsController@progress');
Route::get('/take-test','ViewsController@take_test');
Route::get('/test','ViewsController@test');
Route::get('/logout','ViewsController@logout');


//functionality
Route::post('/login','AuthenticationController@login');
Route::post('/register','AuthenticationController@register');
Route::post('/create_class','ClassesController@create');
Route::get('/delete_class','ClassesController@delete');
Route::post('/create_subject','SubjectController@create');
Route::get('/delete_subject','SubjectController@delete');
Route::post('/create_exam','ExamController@create');
Route::get('/delete_exam','ExamController@delete');
Route::post('/create_question','QuestionsController@create');
Route::get('/delete_question','QuestionsController@delete');
Route::post('/create_answer','AnswersController@create');
Route::get('/delete_answer','AnswersController@delete');
Route::post('/create_test','TestsController@create');
Route::get('/delete_test','TestsController@delete');
Route::post('/finish_exams','TestsController@finish_exams');





