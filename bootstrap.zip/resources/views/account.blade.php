@include('template.header')

<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Modal Header</h4>
      </div>
      <div class="modal-body">
        <p>Some text in the modal.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>


    <!--content-->
    <div class="container-fluid vega-body" >
        
        <div class="row">

            <div class="col-md-2">
                 @include('template.side-bar')
            </div>

            <div class="col-md-10">
                
                <div class="row">
                        <div class="col-md-6">
                    <br>
                    <form>

                    <div class="row">
                        <center>
                          <figure class="figure">
                          <img src="http://placehold.it/250x250" class="figure-img img-fluid" alt="..." height="160" width="160" style="border-radius: 50%;">
                          <figcaption class="figure-caption">A caption for the above image.</figcaption>
                          </figure>
                        </center>
                    </div>

                         <!--Third row-->
                    <div class="row">

                        <!--First column-->
                        <div class="col-md-4">
                            <div class="md-form">
                                <input type="text" id="form41" class="form-control">
                                <label for="form41" class="">Example label</label>
                            </div>
                        </div>

                        <!--Second column-->
                        <div class="col-md-4">
                            <div class="md-form">
                                <input type="text" id="form51" class="form-control">
                                <label for="form51" class="">Example label</label>
                            </div>
                        </div>

                        <!--Third column-->
                        <div class="col-md-4">
                            <div class="md-form">
                                <input type="text" id="form61" class="form-control">
                                <label for="form61" class="">Example label</label>
                            </div>
                        </div>

                    </div>
                    <!--/.Third row-->

                    <!--Second row-->
                    <div class="row">
                        <!--First column-->
                        <div class="col-md-12">

                            <div class="md-form">
                                <textarea type="text" id="form76" class="md-textarea"></textarea>
                                <label for="form76">Basic textarea</label>
                            </div>

                        </div>
                    </div>
                    <!--/.Second row-->

               
                    </form>






                   </div>



                   <div class="col-md-6">
                          <br>
                        <!--Card Default-->
                        <div class="card mdb-color lighten-2 text-center z-depth-2">
                            <div class="card-body">
                                <p class="white-text mb-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere
                                    erat a ante.</p>
                            </div>
                        </div>
                        <!--/.Card Default-->
                       
                   </div>
                    
                </div>
            </div>
                                                            
      
        </div>
    </div>
     <!--/.content-->

@include('template.footer')

 