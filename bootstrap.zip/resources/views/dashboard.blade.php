@include('template.header')

    <!--content-->
    <div class="container-fluid vega-body" >
        
        <div class="row">

            <div class="col-md-2">
                 @include('template.side-bar')
            </div>

            <div class="col-md-10">


           



           </div>
              
               
                 





                
      
                                                            
      
        </div>
    </div>
     <!--/.content-->

@include('template.footer')

 