   <!--Footer-->
    <footer style="background-color: #1b1b1b; background-image: -moz-linear-gradient(top,#222,#111);
            background-image: -webkit-gradient(linear,0 0,0 100%,from(#222),to(#111));
            background-image: -webkit-linear-gradient(top,#222,#111);
            background-image: -o-linear-gradient(top,#222,#111);
            background-image: linear-gradient(to bottom,#222,#111);
            background-repeat: repeat-x;
            border-color: #252525;" class="page-footer center-on-small-only pt-0">
        <!--Copyright-->
        <div class="footer-copyright">
            <div class="container-fluid">
            
                © 2017 Copyright: <a href="#"> Online Portal</a>

            </div>
        </div>
        <!--/.Copyright-->
    </footer>
    <!--/.Footer-->




    <!-- SCRIPTS -->

    <!-- JQuery -->
    <script type="text/javascript" src="<?php echo e(asset('main/js/jquery-3.1.1.min.js')); ?>"></script>

    <!-- Bootstrap dropdown -->
    <script type="text/javascript" src="<?php echo e(asset('main/js/popper.min.js')); ?>"></script>

    <!-- Bootstrap core JavaScript -->
    <script type="text/javascript" src="<?php echo e(asset('main/js/bootstrap.min.js')); ?>"></script>

    <!-- MDB core JavaScript -->
    <script type="text/javascript" src="<?php echo e(asset('main/js/mdb.min.js')); ?>"></script>

    <script>
        new WOW().init();
    </script>

</body>

</html>