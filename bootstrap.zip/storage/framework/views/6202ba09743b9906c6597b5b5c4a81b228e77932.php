<?php echo $__env->make('template.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
     <form method="POST" action="<?php echo e(url('create_exam')); ?>">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">New Exam</h4>
      </div>
      <div class="modal-body">
       
          <div class="form-group">
            <label for="email">Name</label>
            <input type="text" class="form-control" id="email" name="name">
          </div>
         
         <input type="hidden" name="id" value="<?php echo e($subject->id); ?>">
      </div>
      <div class="modal-footer">
         <button type="submit" class="btn btn-default">Submit</button>
      </div>
      </form>
    </div>

  </div>
</div>



    <!--content-->
    <div class="container-fluid vega-body" >
        
        <div class="row">

            <div class="col-md-2">
                 <?php echo $__env->make('template.side-bar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>

            <div class="col-md-10">
            <br>
            <?php if($errors->has('error')): ?>
                        <div class="alert alert-danger alert-dismissable">
                          <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                          <strong>Error!</strong> <?php echo e($errors->first('error')); ?>.
                        </div>
            <?php endif; ?>

            <?php if($errors->has('success')): ?>
                        <div class="alert alert-success alert-dismissable">
                          <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                          <strong>Success!</strong> <?php echo e($errors->first('success')); ?>.
                        </div>
            <?php endif; ?>
            <br>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('home')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url('classes')); ?>">Classes</a></li>
            
            </ol>
            <div class="row">
                <div class="col-md-6">
                    <!--Card Default-->
                    <div class="card mdb-color lighten-2 text-center z-depth-2">
                        <div class="card-body">
                            <p class="white-text mb-0">This section Allow you to create and manage Exams for A subject</p>
                            <p class="white-text mb-0"><?php echo e($subject->name); ?></p>
                            <p class="white-text mb-0">Active</p>

                        </div>
                    </div>
                <!--/.Card Default-->
                </div>

                <div class="col-md-2">
                    
                </div>
                <div class="col-md-1">
                    
                </div>
                <div class="col-md-3">
                    <button type="button" class="btn mdb-color" data-toggle="modal" data-target="#myModal">New Exam</button>

                </div>

                
            </div>

            <div class="row" style="padding: 20px;">                                                    
            <!--Table-->
            <table class="table table-responsive">

                <!--Table head-->
                <thead class="blue-grey lighten-4">
                    <tr>
                        <th>Ref No</th>
                        <th>Name</th>
                        <th>Status</th>
                        <th></th>
                        <th></th>
                    </tr>
                </thead>
                <!--Table head-->

                <!--Table body-->
                <tbody>
                   <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($exam->code); ?></th>
                        <td><?php echo e($exam->name); ?></td>
                        <?php if($exam->status==1): ?>
                            <td>active</td>
                        <?php else: ?>
                            <td>closed</td>
                        <?php endif; ?>
                        <td><a href="<?php echo e(url('questions')); ?>?id=<?php echo e($exam->id); ?>" class="btn btn-default btn-sm">view</a></td>
                        <td><a href="<?php echo e(url('delete_exam')); ?>?id=<?php echo e($exam->id); ?>" onclick="return confirm('Are you sure you want to delete  <?php echo e($exam->name); ?>?');" class="btn btn-danger btn-sm">Remove</a></td>
                    </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
                <!--Table body-->
            </table>
            <!--Table-->

             <center>
                <nav>
              <ul class="pagination pg-blue">
                <li class="page-item disabled">
                  <a class="page-link" href="#" aria-label="Previous">
                    <span aria-hidden="true">&laquo;</span>
                    <span class="sr-only">Previous</span>
                  </a>
                </li>
                <li class="page-item active">
                  <a class="page-link" href="#">1 <span class="sr-only">(current)</span></a>
                </li>
                <li class="page-item"><a class="page-link" href="#">2</a></li>
                <li class="page-item"><a class="page-link" href="#">3</a></li>
                <li class="page-item"><a class="page-link" href="#">4</a></li>
                <li class="page-item"><a class="page-link" href="#">5</a></li>
                <li class="page-item">
                  <a class="page-link" href="#" aria-label="Next">
                    <span aria-hidden="true">&raquo;</span>
                    <span class="sr-only">Next</span>
                  </a>
                </li>
              </ul>
              </nav>
           </center>


        </div>

            </div>
                                                            
      
        </div>
    </div>
     <!--/.content-->

<?php echo $__env->make('template.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

 