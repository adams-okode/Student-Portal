<br>
               <ul class="list-group vega-side-bar">
                    
                  <?php if(session('key')=='1111'): ?>
                  <a href="<?php echo e(url('home')); ?>">
                      <li class="list-group-item active">Home</li>
                  </a>
                  <?php else: ?>
                  <a href="<?php echo e(url('home')); ?>">
                      <li class="list-group-item">Home</li>
                  </a>
                  <?php endif; ?>

                  
                      
                   <?php if(session('key')=='2222'): ?>
                   <a href="<?php echo e(url('classes')); ?>"><li class="list-group-item active">Classes</li> </a>
                   <?php else: ?>
                   <a href="<?php echo e(url('classes')); ?>"><li class="list-group-item">Classes</li> </a>

                   <?php endif; ?>
    
						       <?php if(session('key')=='6666'): ?>
                   <a href="<?php echo e(url('test')); ?>"><li class="list-group-item active" >Test</li> </a>
                   <?php else: ?>
                   <a href="<?php echo e(url('test')); ?>"><li class="list-group-item" >Test</li> </a>

                   <?php endif; ?>
 
                   <?php if(session('key')=='5555'): ?>
                   <a href="<?php echo e(url('students')); ?>"><li class="list-group-item active">Students</li> </a>
                   <?php else: ?>
                   <a href="<?php echo e(url('students')); ?>"><li class="list-group-item">Students</li> </a>

                   <?php endif; ?>

                   <?php if(session('key')=='4444'): ?>
                   <a href="<?php echo e(url('teachers')); ?>"><li class="list-group-item active">Teachers</li> </a>
                   <?php else: ?>
                   <a href="<?php echo e(url('teachers')); ?>"><li class="list-group-item">Teachers</li> </a>

                   <?php endif; ?>

                   <?php if(session('key')=='3333'): ?>
                   <a href="<?php echo e(url('account')); ?>"><li class="list-group-item active">My Account</li> </a>
                   <?php else: ?>
                   <a href="<?php echo e(url('account')); ?>"><li class="list-group-item ">My Account</li> </a>

                   <?php endif; ?>


                </ul>