<?php echo $__env->make('template.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Modal Header</h4>
      </div>
      <div class="modal-body">
        <p>Some text in the modal.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>


    <!--content-->
    <div class="container-fluid vega-body" >
        
        <div class="row">

            <div class="col-md-2">
                 <?php echo $__env->make('template.side-bar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>

            <div class="col-md-10 vega-inbound">
            <br>

                <div class="row container">
                 <div class="card mdb-color lighten-2 text-center z-depth-2 col-md-12">
                    <div class="card-body">
                      <div id="timer" style="color: #ffffff; font-size: 20px; font-weight: bolder;">
                        
                      </div>   
                    </div>
                  </div>               
                </div>
                 <legend></legend>
            <form method="POST" action="<?php echo e(url('finish_exams')); ?>">
                <div class="row container"> 

                
                       <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="card white lighten-2 text-center z-depth-2 col-md-12">
                        <div class="card-body">
                           <div class="row">
                             <p><?php echo e($question->content); ?></p>
                           </div>

                           <div class="row">
                             <?php $__currentLoopData = $answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($answer->question_id == $question->id): ?>
                                <div class="col-md-3">
                                   <input type="checkbox" id="checkbox3" value="<?php echo e($answer->id); ?>:<?php echo e($question->id); ?>" name="<?php echo e($answer->id); ?>:<?php echo e($question->id); ?>">
                                   <label for="checkbox3" class="disabled"><?php echo e($answer->content); ?></label>
                                </div>
                                <?php endif; ?>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </div>
                        </div>
                    </div>
                    <legend></legend>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                <input type="hidden" name="id" value="<?php echo e($test->id); ?>">
                 
                <center><button type="submit" class="btn mdb-color">Submit</button></center> 
              
                

                  </div>
             </form>       
            </div>
                                                      
            

            
        </div>
    </div>
     <!--/.content-->
<?php echo $__env->make('scripts.timer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('template.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


 