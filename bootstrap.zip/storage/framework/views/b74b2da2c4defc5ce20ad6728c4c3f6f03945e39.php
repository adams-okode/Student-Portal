<?php echo $__env->make('template.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Modal Header</h4>
      </div>
      <div class="modal-body">
        <p>Some text in the modal.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>


    <!--content-->
    <div class="container-fluid vega-body" >
        
        <div class="row">

            <div class="col-md-2">
                 <?php echo $__env->make('template.side-bar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>

            <div class="col-md-10">
  
            <br>
            <div class="row">
                <div class="col-md-6">
                    <!--Card Default-->
                        <div class="card mdb-color lighten-2 text-center z-depth-2">
                            <div class="card-body">
                                <p class="white-text mb-0">This section Allow you to create and manage Teachers</p>
                                <p class="white-text mb-0"></p>
                                <p class="white-text mb-0">Active</p>
                            </div>
                        </div>
                    <!--/.Card Default-->
                </div>

                <div class="col-md-2">
                    
                </div>
                <div class="col-md-1">
                    
                </div>
                <div class="col-md-3">
                    <button type="button" class="btn mdb-color" data-toggle="modal" data-target="#myModal">New Teacher</button>

                </div>

                
            </div>

            <div class="row" style="padding: 20px;">                                                    
            <!--Table-->
            <table class="table table-responsive">

                <!--Table head-->
                <thead class="blue-grey lighten-4">
                    <tr>
                        <th>No</th>
                        <th>Name</th>
                        <th></th>
                        <th></th>
                        <th></th>
                    </tr>
                </thead>
                <!--Table head-->

                <!--Table body-->
                <tbody>
                    <tr>
                        <th scope="row">077328</th>
                        <td>John Doe</td>
                        <td></td>
                        <td><a href="<?php echo e(url('answers')); ?>" class="btn btn-default btn-sm">view</a></td>
                        <td><a href="<?php echo e(url('exams')); ?>" class="btn btn-danger btn-sm"><i class="fa fa-times"></i></a></td>
                    </tr>
                    <tr>
                        <th scope="row">077328</th>
                        <td>Jane Doe</td>
                        <td></td>
                        <td><a href="<?php echo e(url('answers')); ?>" class="btn btn-default btn-sm">view</a></td>
                        <td><a href="<?php echo e(url('exams')); ?>" class="btn btn-danger btn-sm"><i class="fa fa-times"></i></a></td>
                    </tr>

                   

                </tbody>
                <!--Table body-->
            </table>
            <!--Table-->

             <center>
                <nav>
              <ul class="pagination pg-blue">
                <li class="page-item disabled">
                  <a class="page-link" href="#" aria-label="Previous">
                    <span aria-hidden="true">&laquo;</span>
                    <span class="sr-only">Previous</span>
                  </a>
                </li>
                <li class="page-item active">
                  <a class="page-link" href="#">1 <span class="sr-only">(current)</span></a>
                </li>
                <li class="page-item"><a class="page-link" href="#">2</a></li>
                <li class="page-item"><a class="page-link" href="#">3</a></li>
                <li class="page-item"><a class="page-link" href="#">4</a></li>
                <li class="page-item"><a class="page-link" href="#">5</a></li>
                <li class="page-item">
                  <a class="page-link" href="#" aria-label="Next">
                    <span aria-hidden="true">&raquo;</span>
                    <span class="sr-only">Next</span>
                  </a>
                </li>
              </ul>
              </nav>
           </center>


        </div>

            </div>
                                                            
      
        </div>
    </div>
     <!--/.content-->

<?php echo $__env->make('template.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

 